# Acceptance scenarios — synthetic specifications,not executed edits

## Social event announcement
Input:authorized source speech,crowd reaction,daylight process and night reveal;brief requires vertical safe zones,disclosure and external audio policy. Route:source-backed announcement,correct reaction chronology,kinetic cues,face-free free lanes,actual night label,source ambience,cues and finalAAC measurements. If Openverse is required,source minimums apply;generated accents cannot impersonate them. Do not copy a numeric claim from a previous campaign.

## Documentary interview
Input:two speakers,context B-roll,screen evidence,landscape delivery,subtle typography. Route:coherent dialogue/source map,J/L-cuts,meaningful longer holds,correct speaker IDs,readable phrase subtitles,music only if appropriate. Strict social2.5s cadence and Cane's disclosure do not apply automatically. Source meaning and intelligibility still block release.

## Sensory craft
Input:close-up process,hand/tool sounds,no dialogue,no music requested. Route:credible synchronized original texture,macro continuity,protected action,minimal editorial copy and no empty speech captions. Do not add a compulsory music bed or reuse whooshes merely to satisfy an unrelated campaign. Label any authorized generated accents accurately.

All examples require real files/rights before execution. They establish profile behavior and tests,not a history of delivered work.
