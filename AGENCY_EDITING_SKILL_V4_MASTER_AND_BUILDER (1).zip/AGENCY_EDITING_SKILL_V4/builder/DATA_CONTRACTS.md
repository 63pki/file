# Data contracts and semantic validation

Schemas in schemas/ define portable top-level contracts. The builder must preserve their meaning and version extensions rather than ignoring unknown required features. Runtime serialization may add supported versioned fields;config validation and semantic validation remain distinct.

## Timing and coordinates
Timeline frame intervals are [start,end),zero-based. Source ranges use explicit source timebase/seconds and source asset ID. FPS is rational num/den. Audio cues use seconds/sample indices with sample rate. A box is [left,top,right,bottom]in the declared coordinate space. Require right>left,bottom>top,finite numbers and correct transform into the canvas. Canvas pixels are not phone pixels. Normalize source rotation/pixel aspect before mapping tracks.

## Overlay instance
id,semantic role(headline,speech,meta,disclosure,counter,evidence),component/type,start/end frames,source_evidence,text/tokens/data,font family/file/weight/size,tier,foreground/background/opacity/stroke/shadow,alignment,layout constraints,animation parameters and reserved/actual bounds. Include counter endpoint/units,evidence and hold duration when applicable. Each added object/group has a stable group ID so density checks count actual display groups,not DOM nodes or letters.

## Caption cue/token
id,role(speech/editorial/translation),text,start/end frame or source-linked precise timestamps,speaker if verified,language,confidence/status,source evidence,word/token timing,highlight intent and typography/layout reference. Translation links original cue. Reject end≤start,invalid source ranges,unexplained overlap and speech data without a source/review state. Empty speech lists are valid for no-speech edits.

## Audio cue
id,asset ID,role(dialogue,production,music,SFX,ambient),source offset/duration,timeline offset,duration,channels,gain/pan/envelopes,processing recipe,rights evidence,original/generated/recorded distinction,seed/tool if generated,master/stem routing. Record the perceptual transient offset if cue alignment uses it. Original Video audio is routed once. Final duration and source window must be valid;effects do not silently extend the composition.

## Protected tracks
id,kind,object identity if available,coordinate space,sampled boxes/polygons,source/transform,confidence,manual corrections,review evidence,lifetime and interpolation policy. Record sampling/coverage;zero measured overlap is not a claim of infallible detection. Person masking requires a supported segmentation/matte source and actual boundary review.

## Gate result invariants
PASS needs export hash,checker version,coverage,applicable thresholds,real measurements and evidence. FAIL needs actionable violations. NOT_APPLICABLE needs a reason tied to the job. NOT_CHECKED/REVIEW_REQUIRED cannot be collapsed to PASS. A null/NaN/missing numeric measurement is invalid for a required numeric check;zero is a valid value where meaningful and must not be treated as missing merely by truthiness.

## Cross-document invariants
Every referenced asset/tool/cue/profile/deliverable exists. All required fields have resolved values before rendering. Sources fit within real probed duration. Timeline IDs/source hashes match the rendered artifact. Profile overrides are explicit and logged. Paths resolve within authorized roots unless an approved external asset is declared. Rights and approval states satisfy the intended use. Gate dependencies invalidate after any relevant source/config/export change.
