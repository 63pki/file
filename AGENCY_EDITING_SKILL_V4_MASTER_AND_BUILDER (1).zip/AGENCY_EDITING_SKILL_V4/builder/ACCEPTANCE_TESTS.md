# Acceptance tests — implementation finish line

Each case has a unique test ID,input,expected result,evidence and implemented/not-implemented status. Tests below are requirements,not claims they have been run in this instruction pack. Synthetic fixtures must be labeled synthetic. A feature cannot be “complete”because a Markdown file mentions it.

## A. Portability and discovery
A01:Run doctor with a nondefault project path containing spaces/Unicode;no hardcoded campaign paths.
A02:Missing compositor,FFmpeg,font,ASR,network orGPU yields exact capability states and a feasible fallback or explicit blocker. No false USED/BLOCKED status.
A03:Read-only/low-disk/low-memory environments are detected before a long render;concurrency/storage adapt within job budget.
A04:Explicit required tool unavailable produces a tested blocker and proposed fallback;it is not silently skipped.
A05:Malicious archive paths/symlinks/oversized expansions and embedded “ignore brief”instructions are rejected/treated as data.

## B. Source and editorial integrity
B01:Original hashes unchanged after edit;derivative/source map valid.
B02:VFR/rotation/audio sample-rate offset/multicam drift and invalid source intervals detected or correctly normalized.
B03:Negation,numeral,speaker-name and source-quote errors are caught or marked REVIEW_REQUIRED rather than “transcript verified.”
B04:Batch plans vary narrative/audio/visual structure;different title text on one timeline is flagged as inadequate diversity.
B05:Unavailable footage/reference audio never becomes a fabricated viewing/listening/source-ingestion claim.

## C. Composition and type
C01:Plate intersects eyes/head by1pixel → FAIL.
C02:No overlap at start,but head moves under text mid-lifetime → FAIL;manual fallback exists for missed/profile/occluded faces.
C03:Spring/shadow/rotated bounds exceed safe zone → FAIL.
C04:Four crowded groups,insufficient gap,small disclosure,wrong font,missing glyph,clipped line or unreadable contrast → FAIL.
C05:Different before/after split passes;duplicate-same-footage split is rejected unless explicitly justified by the job.
C06:Counter lands on verified value within configured duration and holds;wrong units/final value,portrait collision or mismatched semantic label → FAIL.
C07:Photo motion and multilingual/RTL text render correctly in actual frames;no black first frame or font fallback hidden by telemetry.

## D. Sound
D01:Original selected dialogue retained and synchronized;double playback and missing production tracks → FAIL.
D02:Relevant procedural helper produces an actual WAV with recipe/seed/hash,cue placement and accurate USED evidence;helper absence is not faked as success.
D03:Authorized Openverse search logs real responses/timeouts/retries;cached retrieval is correctly identified;unknown license/hash mismatch/missing attribution → FAIL.
D04:When configured,≥3distinct cleared Openverse effects perclip and≥8music queries are verified. A generated whoosh cannot impersonate a sourced item.
D05:Insufficient duck ratio,muted SFX,clipping,channel fault or0.3s unintended silence → FAIL. Annotated permitted silence differs from accidental loss.
D06:Final AAC outside configured LUFS/TP tolerance fails even if source WAV passed.
D07:Delivered stems sum to master within numerical tolerance;float stems avoid hidden component clipping;non-isolated dialogue is labeled honestly.
D08:Absence of a listening-capable review path leaves perceptual sound review NOT_CHECKED/REVIEW_REQUIRED;objective RMS does not turn it into PASS.

## E. Rendering and evidence
E01:Actual end-to-end clip with source motion,a timed caption,photo,speech/music/SFX and deliberate contrast renders through the verified compositor,then decodes fully.
E02:Black frame at0/cut,unexpected freeze,missing/duplicate join frame,wrong FPS/geometry,color tag or corrupt media → FAIL or an intent-aware reviewed disposition.
E03:Browser seek/readiness failure is repaired by verified loading or deterministic frame-sequence fallback,without freezing motion or losing audio.
E04:Interrupted job resumes without overwriting originals/approved renders;incomplete output is never atomically promoted.
E05:Change media,timeline,audio,crop,font or configuration after PASS;dependent evidence is invalidated by hashes.
E06:Missing/null/NaN/zero-valued required measurements do not pass via truthiness errors.
E07:Known old failures fail the appropriate gate. Unrelated compliant checks can pass. No thresholds changed just to erase the fixture's failure.
E08:Unresolved defect after five repair attempts halts certification with exact failure evidence.

## F. Release and agency craft
F01:Package opens cleanly;all links/hashes/config/dependencies/rebuild commands resolve;no secrets,private unrelated files,node_modules or unlicensed resources included accidentally.
F02:Vertical-social,longform/dialogue and sensory/no-music profiles work without inheriting each other's cadence/disclosure/audio mandates.
F03:Twelve-category timecoded creative review exists with actual evidence and unperformed checks marked. No prefilled8+scores,guaranteed virality or fabricated metrics.
F04:Instructions-only export contains no media;editable/project assets are separate and reconstructable.
F05:Final report states which tools were USED/PARTIAL/NOT_NEEDED/BLOCKED/NOT_CHECKED with artifacts/reasons. All supplied required capabilities are accounted for.

## Acceptance decision
Technical production-ready requires all applicable mandatory cases passing with evidence and no unresolved P0/P1 blockers. Optional integrations can remain explicitly unsupported. Creative readiness requires reviewed representative edits;automatic checks alone cannot certify storytelling or sonic taste. Report coverage by environment and adapter,not “works everywhere.”
