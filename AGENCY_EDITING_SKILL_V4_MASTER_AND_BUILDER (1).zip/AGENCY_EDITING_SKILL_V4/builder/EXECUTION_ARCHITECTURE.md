# Implementation architecture and invariants

## Data flow
User brief + separate assets → normalized job/config/rights → media probe + transcript/source map → editorial beat cards → engine-neutral timeline → protected layout/caption/audio/color compilers → selected compositor + media engine → actual masters → independent QA + perceptual review → atomic release + editable handoff.

A capability/tool router sits above adapters,not inside every component. A provenance/evidence graph links inputs,derivatives,timeline,components,export,checks and package. Cache invalidation follows this graph. No single “quality score”replaces the gate graph.

## Portable locations
Resolve skill_root,project_root,asset_root,cache_root,temp_root and deliver_root through config. Support local relative paths and explicit approved remote source locations. Normalize platform paths/Unicode;avoid shell interpolation vulnerabilities. Store only manifest-owned cleanup targets. Use APIs/argument lists rather than concatenating untrusted shell input.

## Timing
Represent frame rates as rational num/den,timecode with explicit source/timebase,frames as integers and audio time/sample indices explicitly. Preserve VFR mappings. Map ASR/source offsets into timeline and caption samples. Do not assume milliseconds,frames and seconds are interchangeable. Segment joins and separate stems share the exact timeline duration.

## Tracking/layout
A track has frame range,shape,coordinate space,transform,confidence/source and review status. Components have semantic roles and time-varying actual bounds. Solver reserves full lifetime,with documented fallback actions. Detection can be automated/manual/hybrid;no model can silently erase the manual evidence. Render adapters expose audit telemetry;independent final-frame checks detect loading/codec defects the solver cannot.

## Audio
Cues reference source/generated asset IDs,source offsets,timeline placement,gain/envelopes,track role,processing and rights. Imported source Video audio is explicitly routed once. Music reference/ducked pairs share mastering calibration for measured reduction. A master processing chain either reproduces via linked stems or its nonlinear/non-reconstructable limitation is explicitly recorded. Final AAC/codec measurements are separate from intermediate PCM measurements.

## Results
Structured checker statuses:PASS,FAIL,NOT_CHECKED,REVIEW_REQUIRED,NOT_APPLICABLE. No boolean-only contracts. Failures identify frames/ranges/rule IDs/measurement/evidence. Technical and perceptual review are separate. Job “done”does not imply “approved to publish.”

## Migration
Version schemas/profiles/component interfaces. Supply migration functions or reject incompatible versions with precise errors. Snapshot the effective resolved config for every render. Preserve user overrides and scope exceptions. Update schemas when the implementation genuinely supports a feature;do not quietly discard unknown fields.
