# Requirements-to-implementation traceability

|Capability/rule family|Specification|Builder output|Acceptance evidence|
|---|---|---|---|
|Authority/security/rights/source truth|00,04,05|Config/rights/source/approval registries|A05,B01–B05,F01|
|Environment and honest tool use|02,03,reference catalogs|Doctor/router/adapters/usage ledger|A01–A04,F05|
|Story/reference/batch diversity|04,06,14,17|Source map,creative cards,timeline|B03–B05,F02–F03|
|Face/action/safe composition|07|Tracker,manual corrections,solver,telemetry|C01–C03,C05|
|Motion/brand/captions|08,09|Reusable components,timing/font engine|C04–C07|
|Procedural/sourced audio,cleanup,mixing|10|Audio adapters,recipes,rights/cues/stems|D01–D08|
|Grade/finish/accessibility|11,17|Source-aware transforms,variant rules|C07,E01–E02,F02–F03|
|Render reliability/resource/resume|12|Orchestrator,cache,atomic outputs|A03,E01–E05|
|Machine gates and honest review|13,14|Executable checkers,evidence/review states|C01–F05|
|Revision/delivery/memory|15,16|State graph,change impact,packager|E04–E08,F01,F04|

The builder adds implementation module paths,test names and actual status. This table is a requirement map,not a prefilled completion certificate.
