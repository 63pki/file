# Builder assignment — implement the Agency Editing Director skill

## One-command assignment
“Implement this specification as a portable editing skill with a working execution layer. Read SKILL.md,all instructions,schemas,profiles and acceptance tests. Build actual adapters,components,CLI,tests and evidence generation. Use the available computer and verified repositories as needed. Deliver the working skill plus setup/rebuild instructions and acceptance evidence. Do not return another conceptual plan or describe unimplemented features as complete. Ask only for an essential authorization/input blocker.”

## Scope
The instruction pack is complete as a specification;your job is implementation and verification,not prompt expansion. The host may already provide Remotion,FFmpeg and other repositories,but availability must be probed. Make paths/config portable. One primary compositor per job;add specialists by capability. Explicitly requested additional engines must run or have a tested,reported blocker. Do not install or invoke all29candidate repositories for appearance.

## Implement these deliverables
1.Environment discovery and a versioned capability registry. Probe OS/architecture,paths,versions,fonts,codecs,CPU/RAM/disk,GPU/backend,network,ASR/tracking and audio helpers. No secret scanning. Store tests,not assumed availability.
2.Project bootstrap from job.json,profile and asset manifest. Validate config,resolve paths,create job/revision folders,preserve originals and prior renders,hash sources and safely extract authorized archives.
3.Media ingest/proxy/source map and transcript/alignment interfaces,including manual verified cue fallback and source meaning review state.
4.Engine-neutral timeline compiler:source ranges/transforms,caption tokens/cues,protected tracks,graphics/audio/color/variants. Detect unsupported fields and invalid source windows.
5.A real compositor adapter,using installed Remotion when available and required,plus an adapter interface and capability handling for Hyperframes/Mirage Tesseract/other selected engines. No fake adapters returning success without rendering. Do not require an uninstalled alternative for unrelated jobs;do test the explicitly required one.
6.Reusable motion/layout components defined in03. Full animated bounds,head/action/hero tracking and free-space solver,minimum typography,disclosure,caption timing,counters,contrasting splits and photo motion. Correct loaded fonts and multilingual text.
7.Sound pipeline:source selection/cleanup;actual supplied procedural helper integration when applicable;authorized Openverse retrieval/cached provenance;music evaluation;multi-track cues/envelopes;source-preserving stems;linked mastering;finalcodec measurement and perceptual-review state. Handle offline/rate limits honestly.
8.Render orchestration with caching,resource budgets,atomic outputs,resume,cancellation boundaries and deterministic decoding fallback. Source audio remains independently preserved.
9.Executable QA gates and negative fixtures from13;per-rule status,actual exported-frame/media checks,source/renderer/export hashes and stale-evidence invalidation. Missing check data fails closed.
10.Client/revision state management,change-impact invalidation,tool-use ledger,creative cards,scope handling and delivery packager. Instructions/media remain separate.
11.An agent-friendly CLI/API and docs. A clean machine should get a concrete setup or blocker report,not a stack trace disguised as readiness.

## Minimum runtime contract
The CLI can be named `agency-edit` or implemented through an equivalent portable entry point. Provide subcommands doctor,init,ingest,compile,render,qa,review-status,package,resume. Each accepts project/config paths rather than campaign-specific constants. Machine-readable output uses stable JSON contracts;human summaries stay short. Nonzero exit on blocked render/failed gate;no silent success on unsupported features. Do not invent a command in documentation until it exists and its help/schema is tested.

## Required code separation
core(config,timeline,source-map,rights,state,evidence);adapters(media,compositor,transcript,tracking,audio-sources,audio-master);components;qa;tests;profiles;templates;docs. The builder chooses language/package structure to fit the verified environment. Preserve media/engine interchange contracts;do not hide editorial decisions in a monolithic rendering script.

## Definition of done
Follow ACCEPTANCE_TESTS.md. Build actual positive/negative fixtures;record runtime versions and outputs. Provide dependency locks/setup recipe,unit/integration tests and a reproducible example that runs without private campaign assets using clearly synthetic fixtures. At least one real compositor + FFmpeg end-to-end route must work. Required-but-blocked alternative engines remain BLOCKED,not “supported.” The instruction package validation report is not runtime acceptance evidence.

## Delivery to the user
A lightweight operating-skill ZIP;separate runtime/source package;separate optional sample/test media;runtime acceptance report;tool capability/support matrix;known limits;one start command. Do not ship credentials or large caches. Do not claim guaranteed industry-level creativity from a test suite:technical readiness and reviewed creative quality are distinct outcomes.
