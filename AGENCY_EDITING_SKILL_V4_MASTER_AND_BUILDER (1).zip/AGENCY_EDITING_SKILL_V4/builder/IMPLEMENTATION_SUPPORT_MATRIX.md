# Runtime support matrix — builder must complete

Status at instruction-package release: NOT_IMPLEMENTED_OR_VERIFIED_BY_THIS_PACKAGE. This is a reporting template, not evidence that integrations are absent from your computer.

| Capability | Required implementation | Current evidence | Builder status |
|---|---|---|---|
| Environment doctor and project contracts | Read-only capability probes, versioned manifests, permissions | Not executed here | NOT_CHECKED |
| FFmpeg media/audio adapter | Source-preserving cuts, normalization, mastering, final-codec measurements | Not executed here | NOT_CHECKED |
| Primary compositor | Verified Remotion or brief-required engine; deterministic motion and actual bounds | Not executed here | NOT_CHECKED |
| Protected layout | Temporal head/action/hero tracks, free-space solver, fail-closed QA | Not executed here | NOT_CHECKED |
| Captions and typography | Accurate timing, font metrics, multilingual shaping, motion bounds | Not executed here | NOT_CHECKED |
| Audio sourcing and procedural helper | Authorized retrieval/generation, provenance, audibility and mixing | Not executed here | NOT_CHECKED |
| QA and repair | Negative fixtures, stale-evidence rejection, bounded repair | Not executed here | NOT_CHECKED |
| Creative and perceptual review | Real representative output review, timecoded observations | Not executed here | NOT_CHECKED |
| Packaging and resume | Reconstructable editable handoff, hashes, atomic outputs | Not executed here | NOT_CHECKED |
| Specialist engines and supplied repositories | Evaluate when relevant; required tools cannot be silently skipped | Reference catalog only | NOT_CHECKED |

For each implemented row, add tested OS/architecture, exact tool versions, adapter version, test IDs, artifact hashes, limitations and reproduction command. Mark unsupported features explicitly. A successful Remotion render does not establish Hyperframes, Tesseract, 3D, segmentation or all 106 style implementations. Never relabel a reference catalog as installed functionality.
