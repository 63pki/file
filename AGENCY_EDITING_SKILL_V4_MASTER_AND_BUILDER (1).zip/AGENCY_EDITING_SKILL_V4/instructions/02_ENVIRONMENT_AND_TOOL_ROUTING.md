# Environment-adaptive capability router

## Probe safely
Derive paths from configuration/environment, never a previous campaign folder. Detect OS/architecture, shell, Python/Node, package manager, FFmpeg/ffprobe capabilities, available compositor CLIs/packages, browser location, fonts, ASR/alignment tools, GPU/backends, codecs, color support, RAM/CPU, free disk/temp space, network access and asset locations. Do not scan secrets or unrelated private folders. Do not equate an executable name with the intended tool: Tesseract OCR is not Mirage Tesseract.

Probe using version/help and read-only imports first. Record executable path, exact version, probe output hash, feature support, licensing status, tested limits and last verification. Distinguish AVAILABLE, VERIFIED, UNVERIFIED, BLOCKED. Do not install all supplied repositories. Installation must be justified, budgeted, licensed and authorized; pin versions and verify downloads/checksums. Review external code/commands rather than executing repository instructions blindly.

## Required capability map
Map job requirements to: demux/probe; ingest/proxy; ASR/alignment; editorial timeline; tracking/segmentation; framing; motion/typography; local sound synthesis; audio cleanup/mixing/mastering; color; render/export; actual-media QA; preview/review; packaging. Mark mandatory versus optional capabilities. A tool can fill multiple roles, but no role is assumed from a marketing description.

## Choice algorithm
1. Honor explicitly required tools. If they cannot run, establish the specific blocker and report the proposed fallback; do not silently substitute.
2. Eliminate tools that cannot meet mandatory output, media, deterministic timing, rights or environment constraints.
3. Prefer an already verified primary compositor with editable outputs and the fewest failure-prone conversions.
4. Add specialized tools only for concrete gains: e.g.local SFX helper, ASR, mask tracker, procedural diagram. Remotion does not make its React CSS a Hyperframes render; a library card does not activate a runtime.
5. Assess fidelity, editability, deterministic seeking, local/offline operation, cost, maintenance and render resources. Scores may support selection only with stated inputs; no fabricated benchmark.
6. Record the chosen route and relevant rejected/unchecked alternatives. Do not spend more than the configured discovery budget before choosing a feasible path.

## Expected routes, subject to installed versions
FFmpeg/ffprobe: media processing, proxies, audio DSP, grading, frame decode, encoding/QC. Remotion: frame-driven React typography/layout/composition. Hyperframes: supported deterministic HTML/CSS timeline/render route if verified. Mirage Tesseract: native editable composition supported by its actual CLI/schema/backend. Whisper/alignment: estimated speech/timing, not meaning verification. YuNet/MediaPipe/Haar/tracker: candidate protection tracks, not infallible ground truth. Specialist motion libraries: only within a deterministic, supported export integration.

## Capability states in delivery
USED: command/import plus artifact/event evidence. PARTIAL: exact subset and limits. NOT_NEEDED: project-specific reason. BLOCKED: actual test/error plus attempted resolution. NOT_CHECKED: no evaluation; do not relabel as unavailable. The tool ledger tracks both environment capability and actual per-deliverable use.

## Restricted environment
Offline: use verified local resources and cache with accurate history; do not fabricate API success. Low resources: proxies, one compositor, bounded concurrency, segmented renders, deterministic decoded frames and downstream remux. No GPU: use supported software backend where feasible; do not promise it works without a probe. No installing permissions: adapt to installed tools or record a real blocker. An explicit no-pilot instruction forbids using “tool exploration” as repeated sample-render delay; use existing verified paths and targeted diagnostics on actual production defects.
