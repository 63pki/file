# Motion direction, graphics and brand finish

## Style selection
Use supplied styles as reference directions. Choose according to subject,tone,reference,source texture and audience—not random style-code assignment. The106-card Chron catalog is text-only reference data,not an installed engine. Respect its/source asset rights. A selected card must be translated into actual palette,type,motion,timing and layout;do not call all cards “activated” because a registry was copied.

## Motion grammar
Define primary/secondary typography,spacing rhythm,palette,plate geometry,corner/stroke/shadow treatment,entry/exit language,transition family,photo motion and beat emphasis. Keep motion coherent across a campaign while varying edit structure. Spring physics should have intentional damping/stiffness and reserve overshoot bounds. Use frame-driven timing,seeds and deterministic particle/audio-reactive values. No wall-clock animation or uncontrolled network media.

## Component capabilities
Kinetic multi-level typography;accurate word highlights;verified-value counters;lower thirds;logo/badge reveals;semantic text masks;independent motion in contrasting splits;Ken Burns/parallax;light/glow/particles;audio-reactive graphics;diagrams/evidence callouts;subtle3D camera moves;multi-scene choreography. These are options,not effects to stack into every shot. Keep tiny metadata legible and preserve faces/critical action. Avoid false branded/record authority:do not invent a Guinness badge or use an official-looking seal without approved assets/claims.

## First frame and photos
For social hooks,frame1 should work as a strong thumbnail with a clear face/object/action and readable hierarchy. It must also be an actual loaded frame,not an empty black canvas with type. Still imagery generally receives intentional slow motion or depth where appropriate;do not fake depth with an unclean cutout. Static archival evidence can be intentional for reading;strict social defaults permit a sub1s static hard hit unless overridden. Parallax must not distort people,documents or product geometry.

## Transitions
Choose from continuity cuts,J/L-cuts,match cuts,whip/occlusion cuts,punches,wipes,graphic bridges and deliberate dissolves. A transition should mark information,energy or space changes. Do not hide missing shots with excessive speed ramps,flashes or random particles. Frame-rate interpolation,optical flow and motion blur can create artifacts;test actual delivered frames and preserve source truth. Label synthetic/interpolated derivatives in provenance.

## Accessibility and comfort
Use adequate contrast and readable dwell. Avoid rapid strobe/high-luminance flicker;screen for photosensitive risk and provide a safer treatment when needed. Do not rely only on red/green or sound to convey essential meaning. Subtitle styling supports,not obstructs,the source. Heavy motion must still permit comprehension on a phone.

## Brand consistency
Use supplied approved assets/fonts when authorized. Verify actual font loading and language coverage;detect fallback and missing glyphs. Grade and graphics should share a coherent palette,not crush source detail to match a swatch. Respect logo clearspace and required disclosure. No fabricated brand statements or unauthorized CTA language.
