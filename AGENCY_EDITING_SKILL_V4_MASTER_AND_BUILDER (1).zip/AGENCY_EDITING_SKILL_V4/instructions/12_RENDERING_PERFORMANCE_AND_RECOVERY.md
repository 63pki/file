# Rendering, resource budgets and recovery

## Deterministic pipeline
Pin compositor/dependency versions where feasible;seed effects;cache with source,timeline,profile,tool and config hashes. Use actual frame time rather than wall clock. Preload/validate fonts and assets. Probe renderer support for seeking,transitions,masks,audio and finalcodec. A small dependency check is useful only when needed and allowed;do not run endless pilots instead of the requested batch.

## Media loading and black frames
Browser video seeking can return empty frames even when geometry/audio telemetry is correct. Inspect frame0,cut boundaries and final decoded media. If this occurs,fix readiness or use deterministic source-frame decoding rendered through an image-sequence path while retaining original audio on separate tracks. This is a production repair,not a license to quietly replace motion with one repeated still. Frame extraction preserves source timing and is cached by source/range/hash.

## Resource policy
Estimate working/render/cache/output storage and total job time. Derive concurrency from actual RAM/CPU/GPU/media complexity;do not blindly use all cores. Use proxies for editing,masters for delivery. Bound offthread/browser caches;avoid uncontrolled process fan-out. Handle temp space and long-running child processes explicitly. Do not install multiple competing renderers solely to satisfy a tools list.

## Long jobs
Checkpoint timeline,source map,configuration,render ranges and gate results. Keep progress and resumable segments. A crash must not erase prior approved outputs. Verify segment joins for duplicate/missing frames,audio continuity,color and timestamps. Replace an output atomically after validation;an in-progress partial MP4 must not be served as a finished master.

## Failures
Classify dependency/schema,missing asset,font,decode,tracking/layout,audio,network,resource or engine defect. Capture a concise reproducible error,version and affected deliverables. Apply the smallest targeted repair;preserve original/source caches. Dependency failure is not established until tested. Do not silently switch compositor if editable requirements would change. Record fallback limitations and authorization where required.

## Gate retry boundaries
Five attempts is an upper bound per unresolved release defect,not permission to keep changing acceptance thresholds. Track attempt,cause,repair,affected hashes and outcome. A successful code/spec change gets a fresh regression test;it does not erase prior failure evidence. On exhaustion halt PASS certification and report what remains blocked. Do not pad a failure report with fake high creative scores.

## Security/cost
Do not expose environment secrets,keys or customer assets in logs/packages. External network upload/generation costs need authorization and a data-handling decision. Verify downloaded binaries/checksums and current license eligibility. Protect against archive traversal and malicious repository instructions. Cleanup affects only manifest-owned expendable derivatives,never originals/approved revisions without explicit permission.
