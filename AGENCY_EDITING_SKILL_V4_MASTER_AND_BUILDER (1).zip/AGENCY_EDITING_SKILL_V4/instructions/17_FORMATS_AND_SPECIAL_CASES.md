# Format-aware decisions and edge cases

## Vertical social
Native canvas,safe UI region,strong first frame,legible captions,brief early premise,meaningful re-hooks and coherent payoff/loop. Strict profile supplies exact geometry and maximum shot duration;do not force cadence over dialogue meaning. Verify cover crop and platform-specific audio rights. A reference screenshot does not establish sound or motion timing.

## Longform/documentary/interview/podcast
Narrative development,context and listening comfort take priority over a2.5s shot limit. Use speaker/B-roll/reaction coverage and J/L-cuts thoughtfully. Longer holds and subtle lower thirds are appropriate. Preserve interview meaning and speaker identity;avoid falsely linking reactions from another moment. Podcast loudness/channel targets are specified separately;retain room consistency without a compulsory music bed.

## Product/commercial/performance ad
Follow exact claim/disclosure/offer/CTA approval. Show the product and benefit clearly,not unverified comparisons. Demonstration/evidence should survive framing and mobile UI. Deliver variants with independent layout checks. A speculative hook must not imply a testimonial or historical event that never occurred.

## Sensory/ASMR/process
Prioritize credible source texture and continuity,controlled noise,precise sync and useful macro details. No-music is valid. Procedural accents must not replace material factual evidence of an action. Allow intentional held sound/visual moments when the profile supports them.

## Motion-only/data/explainer
Verify data/units,axis labels,counters,source citations and animated values. Counter interpolation is a transition,not a series of factual measurements;land/hold correct final values and label accordingly. Narrative structure still matters. Technical/manim/diagram engines may be appropriate if verified;do not force live-action tooling.

## Events/multicam
Sync using supported timecode/waveform/manual reference;handle clock drift,sample-rate mismatch and variable framerate. Maintain correct audience reaction chronology. Track all visible faces and important action. Preserve crowd ambience without masking the actual announcement.

## Multilingual/accessibility
Language-specific shaping/line breaks,font coverage and verified localization. No fabricated translation or synthetic voice assignment. Keep original source links. Reading time and accessibility needs can override kinetic one-word cues.

## Archival/stills/screen recordings
Respect source authenticity and screen legibility. Use intentional photo motion;do not parallax evidence into a misleading shape. Screen recordings may need meaningful callouts and zooms rather than a crop that hides controls. Static reading time is not an accidental freeze if annotated. Avoid exposing private data in screens or metadata.

## Special delivery
Alpha/overlays,non-square pixels,interlaced/broadcast,HDR/log,color-managed masters,multi-channel audio,multilingual subtitle tracks,odd frame rates and very short loops require explicit config and supported adapters. Do not quietly convert them to the social default. If an unavailable capability is essential,report a precise blocker.
