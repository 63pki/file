# Production workflow and state machine

States: DISCOVER → INGEST → EDITORIAL_LOCK → LOOK_AND_SOUND → BUILD → RENDER → MACHINE_QA → PERCEPTUAL_REVIEW → RELEASE. A blocked state records its dependency and owner. A revision creates a new revision ID, not a reset of the whole job.

## 0. Bootstrap and capability discovery
Read the constitution. Create portable job directories/config; register existing work. Probe environment without mutating it. Use tool selection and budgets in02. Output PREFLIGHT, ENVIRONMENT_REPORT and TOOL_USAGE_LEDGER. A skill must not spend the whole task researching available tools.

## 1. Brief and source ingestion
Resolve scope, audience, platform, objective, mandatory content, rights, reference and source assets. Probe media, generate useful proxies/transcripts/contact sheets and source-event maps. Reject dangerous archives/paths. Log gaps and assumptions. Do not hold all editing hostage to one silent/broken audio segment if usable source alternatives exist.

## 2. Editorial lock: concise, actionable
For each deliverable define premise, hook, source evidence, payoff, beat sequence, intended metric and differentiation from the batch. Choose real source intervals. Preserve meaning and provide source timecodes. Keep notes to decisions the timeline needs, not essays about the prompt. Editorial lock is internal by default unless the user requests approval.

## 3. Look and sound
Select treatments from reference/brand/content. For each shot or repeated shot class record three feasible treatments and one selected treatment using short reason tags. Select tools by capability, not brand prestige. Make the typography, composition and audio cue map before rendering. No generic sound bed automatically applied to all concepts; ASMR may intentionally have no music.

## 4. Build
Create an engine-neutral timeline and source map; adapt it to the chosen compositor. Build motion components, face/action tracks, caption timing, color and multi-track sound. Validate static constraints and asset intervals before expensive rendering. Cache by content/version/profile/config hash.

## 5. Render and review
Render requested scope at target quality. Inspect actual export frames, dialogue content, readable mobile previews and sound in context when listening is available. Run objective final-encoded audio measurements. Execute all applicable machine gates. Regression checks establish the gates catch known failures.

## 6. Repair
Classify source/adapter/layout/audio/creative/QA defect. Fix the smallest responsible layer; invalidate dependent caches and rerender affected outputs. Never waive an error by deleting a required check or making its threshold pass the known defect. Budget five attempts per unresolved gate failure; on exhaustion deliver failure evidence and clearly unapproved media if useful, not a falsely certified master.

## 7. Release
All applicable P0/P1 gates pass or have a permitted explicit deviation; all required reviews are completed or honestly labeled. Deliver requested files and an editable/reproducible project, not just a render. Save versioned skill improvements only after actual evidence supports them.

## Progress communication
Start with the action being taken, update at milestones or material blockers, and finish with deliverables and relevant limits. Do not narrate every command or flood chat with generated payloads. If the user changes the task, distinguish additions from replacements and preserve completed work.
