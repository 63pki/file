# Creative review, taste and honest evaluation

## Twelve review categories
1.Brief/audience fit. 2.Hook and clear premise. 3.Source truth and narrative coherence. 4.Payoff and emotional movement. 5.Pacing and continuity. 6.Framing/subject protection. 7.Typography/caption accuracy/readability. 8.Motion/style/reference execution. 9.Dialogue/production intelligibility. 10.Sound design/music/dynamics. 11.Color/compositing/finishing. 12.Platform readiness/accessibility/ending.

For each category record observable strengths,exact timecoded problems,impact and required action. Use PASS/NEEDS_WORK/NOT_REVIEWED or evidence-backed ratings only if requested. A numerical rating requires an explicit anchored rubric and review evidence;never prefill8+values. Technical PASS does not imply reference-match/exceed or industry-level creativity. Declare which reference features were actually comparable and which were unavailable (e.g.sound from screenshots).

## Agency review order
Watch source/context sufficiently to understand what was said and what happened. View the final master uninterrupted for story and rhythm when supported. Review muted for visual hierarchy/caption understanding. Review sound-on and phone/mono for speech,music,cues,dips,tails and fatigue when supported. Inspect hard frames/masks/type and actual first/cut/end frames. Compare to reference mechanisms,not imagined production value. Revisit any story section whose meaning changes when music is removed.

## Audio taste questions
Can the important words be understood without strain? Is sound consistent with the actual action? Does ambience make the location feel real? Are effects motivated and distinguishable from the bed? Is a generated accent falsely presented as recorded evidence? Is there too much whoosh repetition? Does quiet create anticipation without an accidental dropout? Does the reveal feel earned? Do technical repairs audibly pump or distort? If audio was not auditioned,do not answer these as verified facts.

## Creative risk versus clutter
Take risks with a clear hypothesis:unexpected POV,meaningful contrast,graphic evidence,confident type,unusual but coherent cadence. Risk is not obscuring eyes,stacking unreadable copy or adding maximalist particles by default. Sometimes the strongest edit is source dialogue and a precise reaction cut. Do not confuse brand compliance with generic copy;use real stakes and bold honest questions.

## Revisions and stop conditions
Fix material defects before polishing tiny details. Prefer solving the story/composition/audio cause over endlessly adjusting the prompt. Once the brief and release criteria are met,deliver. If a client requests a creative variation,create it as a new revision with change scope;do not rewrite the whole operating system. Metrics after publishing belong to a later authorized learning loop,not invented proof of success now.
