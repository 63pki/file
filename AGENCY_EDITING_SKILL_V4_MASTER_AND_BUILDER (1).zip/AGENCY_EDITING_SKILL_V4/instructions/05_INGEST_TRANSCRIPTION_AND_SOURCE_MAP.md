# Ingest and source understanding

## Source audit
Hash originals;probe video/audio streams,codec,duration,orientation,pixel aspect,frame rate/VFR,timebase,resolution,bit depth,color tags,alpha,channels,sample rate,language and embedded metadata. Verify decode at beginning/middle/end and around errors. Detect missing audio stream versus silent/low-amplitude audio;these are different faults. Honor rotation before generating tracks/proxies. Create lightweight scene/contact/audio summaries and seekable proxies only when helpful.

## Safe ingest
Prevent path traversal,absolute paths,symlink escapes and archive bombs. Check expected sizes/extensions and file signatures. Normalize filenames in a derivative manifest without renaming/deleting originals. External links can expire or point to an HTML download page;verify actual downloaded media and hash. Do not claim assets were ingested if only a thumbnail/listing was read.

## Transcript and alignment
Use supported local ASR/aligner where available;record model/version,language and source mapping. Confidence measures uncertainty,not truth. Correct names,numbers,negations,technical terms and sponsor disclosures against source evidence. Word-level timing is preferred for kinetic captions;fallback to phrase cues/manual visual timing must be labeled. Do not invent dialogue from lip movement or silently use a machine transcript as a verified quote. Multilingual/code-switched material requires proper language detection,fonts,line breaking and human/verified review where available.

## Editorial source map
Store source timecode ranges,speaker identity if verified,meaningful sentences,action/reaction beats,emotional turns,useful ambience/foley,visual quality,context requirements,rights and candidate story role. Audition meaningful audio when supported;otherwise mark what perceptual judgments were not performed. A waveform does not establish a joke or a quote's meaning.

## Low-quality sources
Prefer a better source take before aggressive restoration. For quiet/noisy/reverberant dialogue,process a local derivative with an exact recipe and matched-level comparison;do not destroy consonants trying to make a spectrogram clean. For silent caption reference footage,use visual timing without letting that block usable source editing. For corrupt media,attempt bounded remux/transcode/re-download if authorized;log affected intervals and alternatives. Never repair a missing word by falsely implying another speaker said it.
