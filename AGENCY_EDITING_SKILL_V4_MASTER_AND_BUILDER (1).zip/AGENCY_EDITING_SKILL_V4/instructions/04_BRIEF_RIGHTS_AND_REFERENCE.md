# Brief, rights and reference interpretation

Normalize audience, objective, content type, platforms, languages, clip scope/durations, required moments, reference style, tone, brand system, disclosure, claims, banned language/CTAs, deliverables, usage rights, approval status, budget and deadline. Parse existing task context before asking repeated questions. Missing noncritical values get documented defaults; missing indispensable inputs are genuine blockers.

## Rights ledger
For each footage/photo/audio/font/logo/model/tool: source/owner,license or authorization,permitted commercial/platform/territorial use,attribution,modifications,expiration/restrictions,proof location and status. A download URL is not a license. CC0/PDM status must match the actual item. “Royalty-free” can have exclusions. Platform library music may not transfer to another platform. A catalog reference is not proof a repository or asset is licensed for the intended client. No scrubbing watermarks,implied endorsements or synthetic identity substitutions to bypass rights.

## Reference decomposition
Translate references into observable features: narrative,hook/payoff,source-shot density,framing,subject scale,cut rhythm,caption cadence/type,contrast,animation,grade,music/foley,dynamic range and ending. Reference matching means implementing those mechanisms at comparable quality,not cloning copyrighted media or guessing audio from a screenshot. If only screenshots are supplied,they support visual inspection,not claims about motion,speech or sound.

## Creative freedom with truthful copy
Use bold questions,subjective framing,visual irony and emotional stakes. Do not invent recorded dissent (“they said impossible”),hours of work,measurements,causal claims or founder quotes without support. Preserve genuine ambiguity where source context matters. Avoid deceptive before/after,unmarked reenactment or changing a speaker's answer through reordered fragments.

## Campaign profiles and exceptions
Profile defaults are technical suggestions,not laws for every format. A current brief can require original audio only,no music,no faces covered,exact wording or a static brand slate. Record the decision. Do not carry Cane's disclosure,weight,colors or three-clip scope into a different client. The user can authorize external audio,procedural accents or another treatment;log the authorization and keep source-specific restrictions intact.
