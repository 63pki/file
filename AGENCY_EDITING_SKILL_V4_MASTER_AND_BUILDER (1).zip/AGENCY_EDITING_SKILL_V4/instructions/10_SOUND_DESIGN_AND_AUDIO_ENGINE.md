# Sound design, synthesis, restoration and mastering

## Sound is an editorial system
Plan speech,production ambience,foley,music,designed accents and intentional quiet by beat. Preserve human personality,room/event context and useful source sounds. A music-led edit is a choice,not the default for every concept. ASMR/process can be source-led with no music. Effects must support something visible or narratively meaningful;do not sprinkle whooshes on every caption to claim sound design.

## Capability-led sound route
1.Select the best source take and meaningful original sound.
2.Evaluate needed dialogue cleanup with the supplied skill guidance and available tools.
3.Locate/test relevant supplied local synthesis helpers for missing accents before defaulting to unrelated cached sounds.
4.Search approved libraries/APIs for appropriate recorded SFX/music/foley and verify rights.
5.Build multi-track cues with timing,fades,ducking,EQ/dynamics and controlled peaks.
6.Measure final encoded output AND review sound in context when playback is available;label unperformed listening honestly.

## Local procedural generation
The supplied Mirage Tesseract skill reference describes tesseract_sound.py list/make with presets such as soft-tap,dry-click,soft-pop,clear-ping,air-whoosh,short-riser,downlifter,soft-impact. Verify actual helper files,syntax,license and dependencies;do not claim they are installed from a documentation mention. Record recipe,version,seed,duration,processing and output hash. These are small synthetic accents,not a universal music generator,voice restorer or authentic recorded carving foley. A generated accent can support a cut without being misrepresented as synchronous real source sound. Other verified local synthesis routes may be used with the same provenance standard. Do not assume generated audio is CC0 or rights-free.

## Approved retrieval and fallback
Follow the current audio policy. Original-only means no external bed or helper output without authorization. Openverse profile:query https://api.openverse.org/v1/audio/ with q,license=cc0,pdm,page_size=20;verify current API behavior;maximum3attempts with bounded exponential backoff,record timeouts/HTTP/rate-limit responses. Evaluate at least8music searches when that profile requires it;log candidate fit/rejection,not just query strings. Three DISTINCT cleared Openverse SFX perclip are mandatory only for the corresponding configured campaign requirement. Procedural effects do not silently replace that source mandate. Reuse valid cached items with honest original retrieval/license/hash;never invent a new successful download. Log title,creator,item ID,license/URL,source/direct URL,query/params,hash,assignment,cue time,trim,gain and processing. If required sourcing cannot be met,record a blocker/deviation,not a fake asset.

## Music direction
Select mood,tempo,arrangement,dynamics and usable structure to match the story. Cut/rearrange where rights allow;avoid obvious repeating seams or cutting a phrase awkwardly. A bed must leave speech spectral/dynamic space. Avoid music whose emotional meaning contradicts source content. Keep supplied chosen music unless the brief permits replacing it. Do not use an unverified demo track because it happens to be bundled with a repository.

## Dialogue and restoration
Speech at0dB means a RELATIVE reference,not0dBFS peaks. Use gain staging,high-pass/EQ,controlled compression,de-essing and noise/reverb processing only as needed. Preserve natural breaths/consonants;do not gate words or over-denoise. Compare processed/original at matched loudness. Center dialogue appropriately;check clipping,sibilance,plosives,wind,hum and multiple-speaker balance. Keep latency and lip sync after DSP/time-stretch. Do not invent unsupported native sidechain/EQ fields in an engine schema;prepare a derivative using a real DSP tool.

## Mixing and cues
Separate production/dialogue,music,SFX,ambient and finalmix;keep an unducked music reference where duck verification requires it. Plan cue alignment to an effect's actual perceptual transient,not merely file start. Use attack/release ramps and tails. Distinguish timed speech-window ducking from signal-driven sidechain compression in reporting. Strict social default:music reduces14–18dB relative to its unducked reference during active speech;configure non-speech bed and SFX/ambient by intelligibility,not fixed full-scale assumptions. Linked mastering preserves relative track balance and stem sums;avoid normalizing each stem independently.

## Quiet and climax
For no-dead-air profiles,run final AAC silencedetect at−45dB for≥0.25s with zero unintended events. During a0.5s pre-reveal music dropout retain suitable ambience/room tone/tail. Do not loop a speech fragment as “room tone.” Intentional total silence can be artistically valid in another explicitly configured profile;tag it in the timeline so checks distinguish it from loss of audio. Do not force a noisy bed into a deliberately silent brand ident merely to pass a borrowed social rule.

## Mastering and delivery
Strict social target−14±0.5LUFS integrated,truepeak≤−1dBTP,48kHz stereo unless specified. Other platforms/broadcast/podcasts derive explicit targets/channel layouts from the brief. Leave encoding headroom;measure actual AAC/other finalcodec,not only a PCM intermediate. Single-pass loudnorm is not proof of the target;record normalization mode and measured output. Check mono compatibility,phase,channel routing,head/tail clicks,overs,dropouts,pumping and dialogue/music balance. Source-only/very short effects may not have meaningful integrated loudness.

Component stems can exceed the final summed peak when tracks cancel;float32 WAV prevents premature clipping. Deliver required PCM format for finalmix and document bit depth/sample rate. Verify stems reconstruct the master within numerical tolerance,including linked limiting/master gain;do not hide nonlinear postprocessing that prevents reconstruction. Label a mixed production stem as dialogue+ambience rather than falsely claiming isolated dialogue. Source rights logs include every non-source element and derivative recipe.
