# Composition, tracking and protected placement

## Native canvas and focal intent
Use the current profile's aspect ratio,dimensions,FPS and safe geometry. Default to subject-aware fill for a vertical full-bleed brief,not an arbitrary center crop that removes the speaker,tool,certificate or reveal. Track focal points and pan/scan deliberately. Protect critical action within usable viewing regions where source geometry permits;if impossible,choose another framing/treatment and report the tradeoff. Source-intrinsic logos/text in the scenery are distinct from added graphics;do not falsely certify every pixel of scenery as platform-safe typography.

No random tiny PiP. Splits must compare distinct,meaningful views/states and have readable subject scale. Never duplicate the same footage merely to fill space. Avoid cutting off heads/hands at awkward joints or allowing split boundaries to hide the important action. Establish clear visual priority;do not force full-screen type behind a busy face.

## Protected zones
HEAD:face/head detected with a verified method;expand raw box +25%top,+15%each side,+20%bottom by default. ACTION:active hands,tools,demonstrations,documents/certificates. HERO:product/key carving/brand detail or evidence the viewer must inspect. DISCLOSURE:reserved area for required attribution/ad wording. Different jobs can have different protected objects. Detect/sample at least every third frame plus both shot boundaries and overlay entrances/exits/animation extrema. Interpolate tracking conservatively and use lifetime unions where needed. Sampled detection alone cannot prove zero overlap on unsampled frames;in ambiguous/fast motion,use manual expanded tracks or denser verification.

Manual corrections are first-class data:frame range,box/polygon,reason,review image and reviewer/source. Retain rejected detector boxes. Do not suppress genuine faces to make a test pass. Close-ups,occlusion,multiple people,profile views and sculptures require special review. Segmentation-based behind-person text is allowed only if boundaries remain clean throughout;otherwise choose a different composition.

## Placement solver
Available area = configured safe area minus protected zones minus disclosure reservations minus concurrently active elements. Solve full rendered rectangles including plate,shadow,stroke,scale/rotation and spring overshoot for the ENTIRE active lifetime. Route by semantic role and viewer reading order. Keep one primary alignment per clip unless a deliberate design system defines the exception.

Fallback:alternate clear lane → fit/reflow within tier floors → shorten nonverbatim editorial copy → change focal crop/shot → verified masking → delay/shorten overlay → hold graphic until cut. Do not silently truncate speech captions or shrink the disclosure. If there is no legal space,source-only framing is preferable to a face collision. A fixed disclosure anchor is valid only if it is itself clear for the whole shot;reframe or reserve a safe alternate when necessary.

## Strict vertical social profile
For1080×1920,use added-text safe boxX80–900,Y220–1500. Top dead zoneY0–220;bottom1500–1920;right engagement regionX900–1080. Candidate upper laneY240–560;lower980–1340;disclosureY1420–1480. Scale only if the profile explicitly allows it;verify against current platform UI and placement rather than calling one template universally safe. Face center below760 favors upper lane;above760 favors lower—but collision checks override this heuristic. A head over45%canvas height limits editorial copy to at most two words in a free lower lane or holds it to the next cut. All exact thresholds are profile data,not scattered magic numbers.

## Telemetry
Record actual renderer bounds,role,font,tier,colors,active frame,animation state,protected tracks and source mapping,linked to timeline/export hashes. Audit glyph and full plate extents,including clipped/overflowed text. Render representative mobile/debug sheets with safe area,head/action/hero zones and added-element boxes. Do not claim actual-render OCR or segmentation when only DOM/project telemetry was measured.
