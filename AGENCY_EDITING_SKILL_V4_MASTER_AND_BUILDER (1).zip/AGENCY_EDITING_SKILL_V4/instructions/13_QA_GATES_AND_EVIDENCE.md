# Release gates: machine-checkable and review-required

Every result contains status,rule IDs,job/revision/export hash,checker version,thresholds,measurement method,coverage,evidence,failures and limitations. Allowed:PASS,FAIL,NOT_CHECKED,REVIEW_REQUIRED,NOT_APPLICABLE. PASS requires evidence;missing measurements,NaN,null,absent artifacts or unexecuted checks cannot pass. NOT_APPLICABLE requires a factual condition,not a convenient omission.

## Required gate families
1.Layout/face/action:actual full plate/glyph/effect bounds versus protected tracks;every third frame plus boundaries/entrances/exits/extrema minimum;denser/manual verification for ambiguity. Zero prohibited head overlap. Save debug images and exact intersection areas/frames.
2.Safe geometry:current canvas,safe areas,required disclosure and variant-specific positions. Measure actual rendering/project telemetry tied to final export,plus decoded-frame inspection. Do not claim telemetry is OCR.
3.Type/readability:font loading/glyph coverage,tier floors/ceilings,contrast,clipping,line count,width,area,hierarchy,dwell,spacing and crowding. Mobile previews at required sizes.
4.Caption/content:source-linked words,numbers/names/negations,language,word/cue timing and speaker labels. Semantics/quote integrity require source review,not just string matching.
5.Audio:finalcodec LUFS/TP/silence,channels/sample rate,clipping/click candidates,sync,duck/reference ratio,cue presence/audibility indicators,head/tail and numerical stem reconstruction. Machine energy is not proof of artistic impact or speech intelligibility.
6.Provenance:source/hash,license/authorization,attribution,tool/recipe,all audio cue assignments and required search count/history. Do not mix old asset logs with a new export without correct links.
7.Media completeness:decode EVERY final frame;verify dimensions,FPS/timebase,duration/frame count,A/V streams,orientation,pixel aspect,source windows/joins,black/frozen/duplicate-frame candidates and actual first/cut/end frames. Distinguish intentional dark/held scenes from accidental decode failure by annotated editorial intent;do not globally weaken thresholds.
8.Semantic/brand:caption/visual state sync,verified counter endpoint/hold,claim evidence,approved logo,disclosure,CTA/banned wording. A “glow” label belongs on actual illumination if phrased as a current state.
9.Export/package:container/codec/pixel format/audio,color tags,caption encoding,fast-start if needed,editable project dependency integrity,media linkage,rebuild documentation and no secrets/unapproved files.
10.Creative/perceptual:source meaning,story,payoff,pacing,framing,motion taste,sound in context,grade and reference quality. This is not fully automatable;use14.

## Executable checkers
Implement at least qa_text_faces,qa_safe_zone,qa_text_size,qa_stack,qa_audio,qa_provenance and qa_media,plus semantic/caption/package checks or equivalent explicit modules. Invoke directly from the build pipeline. Keep gate contracts engine-independent;adapter telemetry supplies actual bounds and source maps. Do not make a packaging script invent per-clip scores.

## Checker validation
Use real prior failures when available;otherwise synthetic fixtures clearly labeled as synthetic. Required cases:plate crosses eyes;face moves under overlay after entry;spring overshoots;four crowded groups;tiny disclosure;missing font/glyph;caption negation mismatch;wrong counter endpoint;day/night label mismatch;0.3s unintended silence;insufficient duck;finalAAC overshoot;SFX absent;unknown license;stale hashes;black first/cut frame;unexpected freeze;corrupt source;missing measurement. Each fails the appropriate gate. A compliant old safe-zone check can legitimately pass while a face check fails. Do not force every gate to fail the same file.

## Evidence versus claims
Save source/actual frame hashes,frame indices and coverage. A contact sheet is sampled review,not proof every frame was visually inspected. A detector has uncertainty;manual fallback is not a secret waiver. Listening or viewing claims require an actual supported review path. If the environment cannot audition audio,record objective checks and REVIEW_REQUIRED for listening;do not report a completed perceptual audio pass. Record deviations without burying them in a “100%PASS” headline.

## Release decision
All applicable P0/P1 gates must pass or have an explicitly permitted scoped deviation. Perceptual review has a declared completion state and owner. Unapproved/partial outputs may be delivered for review but must not be labeled approved masters. Final evidence is invalidated when dependent media/config changes.
