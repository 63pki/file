# Color, finishing and accessibility

## Source-aware color pipeline
Identify source color space,transfer,primaries,range,bit depth,HDR metadata and camera/log transforms. Do not apply one LUT indiscriminately or label SDR footage HDR by changing tags. Normalize correctly,match adjacent shots,then apply a campaign look. Preserve natural skin,highlight detail,product fidelity and readable shadows. A warm pumpkin campaign may use warm highlights/orange emphasis;that is not a universal grade for other clients.

Separate technical transform,exposure/white balance/shot match and creative look. Store parameter values/LUT identity/rights and transform order. Avoid double tone mapping or grading both source derivative and compositor layer unintentionally. Verify render/browser color differences and actual export tags/range. Use scopes/measurement where available;phone previews supplement,not replace,color-managed review. Explicitly report if calibrated review is unavailable.

## Finishing
Use appropriate resize/filter/sharpening;do not oversharpen low-quality footage. Denoise conservatively and retain texture. Verify masks,tracking edges,keying,composite seams,split alignment,motion blur and speed ramps at full resolution. Check alpha edges/premultiplication and correct export support if overlays are requested. Optical flow,upscale and stabilization can warp faces/tools;inspect actual frames and mark derivatives. No claim that generated/interpolated frames restore information that never existed.

## Brand and evidence
Verify logos,legal lines,product color and evidence documents remain accurate and legible. Do not remove material information from a certificate or chart through cropping/retouching. Source-intrinsic noise/blemishes may be corrected only within brief and source truth. No deceptive beauty/product before-and-after treatment.

## Accessibility
Ensure captions,reading time,contrast,language coverage and essential sound-independent meaning. Offer clean captions/transcript and accessibility alternatives when requested. Flag strobing/flicker and unsafe rapid brightness patterns;choose safer treatment. Do not use color alone for essential distinctions. Preserve comprehensible speech and avoid extreme transient loudness. Required accessibility/disclosure specifications override stylistic preference.

## Export variants
Platform variants may need separate framing/text positions,audio rights or end cards. Do not assume cropping a16:9 master automatically creates a good9:16 edit. Derive versions from the same source timeline with per-variant layouts and rerun relevant gates. Check thumbnails,cover crops,clean/textless versions,alpha overlays and caption tracks as distinct deliverables.
