# Editorial intelligence and creative direction

## Choose the story before choosing an effect
Identify what a viewer learns,feels or wants to see resolved. Select the strongest real source moments for premise,tension,development,payoff and ending. A technically compliant montage can still be a poor edit. Reject vague labels that describe shots without giving them meaning.

## Per-deliverable creative card
One sentence hypothesis;target audience/objective;source-backed hook;payoff;beat map with source ranges;emotional/pacing curve;visual/sound concept;primary design metric;reference mechanisms;distinctive treatment;mandatory material;known risks. Metrics are design intent unless platform analytics are actually available. Never promise guaranteed virality or fabricate watch-time data.

## Batch diversity
Vary narrative mechanism,source emphasis,pacing,audio strategy,visual grammar and payoff. Possible families:dialogue-led announcement,human craft,sensory process,before/after,evidence-led explanation,inside POV,founder reaction,cinematic atmosphere,comparative detail and a coherent loop. Use only angles supported by assets. Do not force every campaign into these ten concepts or repeat one layout with ten headlines. Maintain brand cohesion through palette,type and grade,not identical structures.

## Retention without deception
For short-form social:motion/action/focal point on frame1;clear curiosity/stakes early;remove dead setup;re-hook with meaningful new information or a genuine shift;pay off what the hook promised. Fast cuts can reset attention but arbitrary cuts hurt comprehension. Default shortform maximum shot2.5s is configurable;intentional emotional pauses,ASMR,interviews and longform can need longer holds. Do not interrupt every meaningful sentence to satisfy a numeric cadence. A loop must be coherent,not a misleading broken sentence.

## Three-treatment choice
For each shot or reused shot class record three concise treatment candidates (e.g.native crop+type,contrast split,source-only hold) and a selection reason linked to story/space/audio. Do not expose hidden chain-of-thought;store only production decisions and observable tradeoffs. Advanced choices include kinetic hierarchy,counters,semantic masks,controlled particles,audio-reactive motion,3D/parallax and graphical evidence. Use complexity only when it earns its place and remains reviewable.

## Agency craft checks
Is the hook specific rather than generic? Does the payoff arrive before interest decays? Are reactions causally linked to the correct moment? Do cuts preserve eyelines,screen direction and emotional continuity where relevant? Does B-roll clarify rather than hide missing context? Is humor allowed to breathe? Are graphic claims supported? Can a viewer understand the main point muted and still enjoy the sound-on version? Does the ending resolve or deliberately loop? Would removing an effect improve the story? Revise the edit,not merely its score sheet.
