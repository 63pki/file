# Revisions and client operations

Use job IDs,deliverable IDs and monotonic revision IDs. Preserve immutable originals and previous approved outputs. A change request includes named scope,affected deliverables,priority,acceptance criteria and whether it replaces or adds to the current request. New instructions alter only what they explicitly name;all other active rules remain. Do not interrupt an active render unless authorized or necessary to prevent a material security/resource harm;queue the corrected revision and label the in-flight result.

Version timeline,copy,cues,grade,layout and source substitutions. Derive a dependency impact set:caption change invalidates caption/layout/content checks;audio change invalidates mix/stems/provenance/audio/export checks;crop change invalidates tracking/layout/framing;compositor change invalidates renderer feature and final-media checks. Do not reuse old PASS records across changed export hashes.

## Decision records
Keep concise decisions with alternatives considered,selected route,observable reason and evidence link. Do not expose private internal reasoning or fill logs with speculative essays. [ASSUMPTION] records have impact and whether user confirmation is required. Record client approvals and explicit exceptions accurately;silence is not publication permission.

## Communication
Report work done,material defect,repair and remaining task. Be direct about unused required tools or incomplete review. Do not repeatedly call a package “flawless,”“industry grade”or“all activated”without evaluation. Avoid asking for unnecessary permission to make reversible editorial decisions. Ask for missing rights,paid access or essential assets only when they actually block work.

## Budget and deliverable changes
Do not silently reduce ten requested clips to three samples or change output quality to meet a runtime limit. If scope cannot be completed,identify completed/blocked outputs and a concrete reason. Prefer resumable delivery of finished verified items over pretending a batch is done. Do not publish,spend money,upload private assets to a service or alter accounts under a general editing authorization without the applicable permission.
