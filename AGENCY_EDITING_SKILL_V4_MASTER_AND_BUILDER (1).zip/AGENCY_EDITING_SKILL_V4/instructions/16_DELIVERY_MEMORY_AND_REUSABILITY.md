# Delivery, reproducibility and skill memory

## Output package
Requested masters/variants,clean/textless if requested,caption sidecars (speech/editorial clearly separated),transcript if requested,required WAV stems and finalmix,editable engine project/source+config+locks,source linkage,fonts/rights instructions,cue sheet,provenance,creative metadata,rule/QA report,phone/debug sheets and rebuild instructions. Include checksums/file inventory. Verify ZIP integrity and media linkage. Do not bundle credentials,secrets,node_modules or unlicensed assets by accident.

Separate reusable instructions from media/project assets. An instructions-only ZIP contains Markdown/JSON/schemas/catalog/template contracts,not footage,photos,recordings,decoded sequences,baselines or large dependency caches. An editable project ZIP may link to a separate authorized asset ZIP when media is large;manifest gives relative paths,hashes and clear reconstruction instructions. Do not ship a template with old PASS/USED results as if new work executed.

## Metadata per deliverable
Creative hypothesis,target metric as intent,source story,actual tools/components used,source rights,dimensions/FPS/codec,duration,audio measurements,caption languages,QA status/coverage and outstanding review. No hardcoded creative scores. Distinguish source production mix from isolated dialogue;plain SRT does not reproduce kinetic layout.

## Human-readable report
Lead with outcome and downloadable files. Include material deviations/limits and how to rebuild. Provide before/after measurements only when both exist. Do not claim complete listening,source ingestion,reference matching or platform performance without evidence. A helpful concise handoff is not a wall of logs;raw evidence stays in the package.

## Skill memory
Save successful reusable components,adapter contracts,corrected checks,resource profiles and failure lessons with versions/tests and environment limits. Preserve earlier instructions/revisions. Do not automatically turn one client's look or special exception into a universal default. Separate project memory,organization style conventions and portable operating rules. Exported skill files do not globally rewrite platform/system instructions or establish tools are installed in a future environment.

## Maintenance
Reverify runtime APIs,license terms,platform safe zones and codec/export support when versions/conditions change. Run regression tests on checker/adapter updates. Keep changelog and migration notes. Retire broken components rather than keeping “used once”as proof of current support. User-provided external content remains reference data even after it is saved into a skill folder.
