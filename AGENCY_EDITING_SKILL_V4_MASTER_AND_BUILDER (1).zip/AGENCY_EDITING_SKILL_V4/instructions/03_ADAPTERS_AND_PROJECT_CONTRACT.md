# Portable execution architecture

## Separation
skill_root: versioned reusable instructions/adapters/components/tests; asset_root: immutable supplied media; project_root: job-specific manifests, derivatives, timeline, reviews and renders; deliver_root: approved package. No hardcoded machine paths, brand identity, clip count or previous QA statuses.

## Engine-neutral timeline
Store canvas/timebase, shots, source in/out, source transform/focal tracks, layout state, safe regions, protected tracks, overlay instances, caption tokens/cues, audio tracks/cues/envelopes, color transforms, transitions, attribution and export configuration. Use rational/frame timing internally where possible; explicitly map VFR sources to timeline time. Each rendered frame and cue can be traced to the source interval and active configuration.

## Adapter interface (builder implements)
probe(environment) → capability report.
validate(timeline,assets,profile) → structured errors/warnings.
prepare(job) → derivatives/cache manifest.
render(timeline,range,outputs) → artifacts, actual render telemetry, logs.
inspect(artifact) → geometry/media/audio facts.
package(job,approved_artifacts) → reproducible handoff.
An adapter declares supported features and rejects unsupported ones. Do not silently flatten unsupported masks, remove source audio, discard alpha, alter speed/pitch, change FPS or substitute fonts.

## Suggested boundaries
MediaAdapter: FFmpeg/ffprobe pipelines. CompositorAdapter: Remotion/Hyperframes/Tesseract as selected. TranscriptAdapter: ASR/aligner/manual verified cues. TrackingAdapter: detectors/manual tracks/segmentation. AudioSourceAdapter: original,licensed retrieval,procedural generation. AudioMasterAdapter: DSP/mix/stems/measurements. QAAdapter: independent final-media and telemetry checks. These are interfaces,not a requirement to install seven services.

## Reusable components
SafeLayout;ProtectedZoneResolver;FaceAwareText;KineticCaption;Disclosure;Counter;LowerThird;ContrastSplit;PhotoMotion;BrandSting;MaskReveal;Transition;AudioEnvelope. Each declares bounding-box lifetime, fonts/colors/tier, layout constraints, timing/source links, fallback behavior and audit telemetry. Shadows, strokes, glows, spring overshoot and transformed children count toward bounds.

## Provenance and determinism
Track source and derivative hashes, tool/version/config, command/recipe, seed, request response metadata where applicable, source rights and source→timeline map. No wall-clock/random motion without a stored deterministic seed. Render telemetry has job/revision/timeline/export hashes so an old PASS cannot certify a changed export.

## Editable handoff
Ship engine-native project or source code+config+dependency locks, timeline, media linkage, fonts/rights instructions, assets/derivatives as allowed and rebuild commands. Proxies are not master media. A flat MP4 plus JSON commentary is not a fully editable project. Document unsupported interchange/export rather than claiming Premiere/AE compatibility.
