# Caption engine and typographic system

## Different text roles
Speech captions represent spoken words;editorial headlines are added copy;metadata identifies source/speaker;disclosures satisfy requirements;graphic evidence labels explain a verified visual. Do not merge these into one transcript or put rewritten marketing copy in quotation marks. SRT supports time/text,not kinetic animation or rich spatial layout;deliver motion baked into the master plus appropriate sidecars and editable cue data.

## Cue accuracy
Use word/timestamp data from an actual transcript/alignment or verified manual timing. Preserve negations,names,numbers and sentence meaning. No dummy parser call counted as a caption engine. In Remotion,@remotion/captions must parse/use actual cues,not an unrelated example. Other engines may use equivalent actual timed data. Social speech groups normally1–3words;longform/accessibility subtitles may require readable two-line phrase cues. Do not flash every tiny syllable too briefly or split a key number into an unreadable fragment. Keep punctuation and speaker changes intelligible.

## Strict1080p vertical mobile defaults
Disclosure40–48px;metadata44–52;speech72–96;headline110–170;hero numerals160–230. Headline≤2lines and≤3words/line where feasible;block width≤780. Display type≥1.8×meta;adjacent conceptual tiers≥1.4×. Disclosure and speaker metadata belong to the same meta tier;do not require them to differ by1.4×. Do not force a transient headline and speech caption to coexist solely to satisfy hierarchy.

Max2content groups+1disclosure;single plate≤14%canvas;total added graphics≤22%;≥48px vertical gap;caption bottom≥56px above disclosure top. Disclosure pill uses white bold on≥70%black,with measured contrast and padding. At Y1420–1480 the60px height conflicts with some font/line-height/padding combinations:explicitly solve and inspect actual glyphs. A previous40px/32px line-height/14px vertical+24px horizontal combination fit that lane;it is not a universal font metric guarantee. Do not mask clipping with overflow:hidden.

## Animation and highlights
Time entries to actual speech/cadence. Animate within a reserved legal box;do not scale text below the readable minimum or spring through a face. Highlight semantically important words with approved contrast-safe accents. Store per-word/cue timing,active-word state and power-word selection. Avoid highlighting every word or using giant captions to compensate for a weak story. Lower thirds should exit before dense speech captions where stacking would crowd the subject.

## Internationalization
Correct Unicode normalization,glyph coverage,RTL/bidi,ligatures,language-specific punctuation and line breaking. Shape Arabic/Indic text with a suitable renderer. Do not approximate complex scripts with letter spacing. Translation/localization must preserve meaning;provide original and translated cue links when requested and rights allow. Content warnings or accessibility needs can change presentation defaults.

## Verification
Measure actual loaded font and full glyph/plate bounds,contrast over worst-case background,spacing,dwell and clipping. Inspect390×693 and270×480 previews for a1080×1920 master. Verify subtitle encoding,timestamps,overlaps and start/end behavior. Open captions and embedded/sidecar tracks must not accidentally double up. Empty dialogue SRT is legitimate for a no-speech ASMR/montage edit;label editorial cues separately.
