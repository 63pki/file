# What “ready”means

1.Instruction-ready:all required modules/contracts/profiles/templates exist and package links/JSON are valid.
2.Runtime-ready:a builder has implemented and passed applicable acceptance tests on named environments/adapters,with exact setup and evidence.
3.Creatively reviewed:representative actual edits have been evaluated for story,framing,captions,sound and finishing against the brief/reference.
4.Client-approved:the user/client has approved the deliverable where required.
5.Publish-authorized:explicit publication/account permission exists.

These states are different. A valid ZIP is not a tested runtime;technical PASS is not excellent editing;excellent editing is not publishing permission. Release reports must state the real state,not collapse all five into “industry-grade.”
