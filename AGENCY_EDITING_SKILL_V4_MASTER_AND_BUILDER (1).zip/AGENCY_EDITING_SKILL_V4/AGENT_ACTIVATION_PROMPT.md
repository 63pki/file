# Paste this to the editing agent

Use the attached Agency Editing Director v4 skill for the CURRENT editing task. Read SKILL.md and the constitution,then load the relevant modules by production phase. Discover your real computer capabilities;do not assume supplied repository links are installed or usable. Resolve the campaign brief and assets supplied separately,select the best verified tool route,then execute and deliver the requested edit scope.

Preserve original audio and source meaning. Build meaningful creative variation,subject-aware framing,accurate kinetic captions,real sound design,consistent grade and editable outputs. Enforce the current profile's layout/audio/export rules with executable checks. Inspect actual masters,not only code or contact sheets. Report precisely which tools were used and which checks were not performed. Do not claim listening,compatibility,rights,style activation or PASS without evidence.

Use your autonomy for reversible editorial decisions. Record [ASSUMPTION] decisions and continue where safe. Ask only for essential missing inputs,authorization or an unresolved contradiction. Do not return another prompt-improvement plan instead of the requested work. If implementation is missing but feasible,build it locally;do not call the instruction pack a fully implemented runtime. Honor the configured five-attempt release-gate repair limit and hand off remaining failures honestly.

The actual campaign/task follows here or in the separate brief. Do not use sample/template content as real source material.
