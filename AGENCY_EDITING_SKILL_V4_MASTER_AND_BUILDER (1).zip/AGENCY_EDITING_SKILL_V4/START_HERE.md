# Start here

## For an editing agent
Read SKILL.md. Give the agent this folder plus the CURRENT user task and a separate asset folder/manifest. Start with profiles/shortform_social.json for vertical social, or choose a more suitable profile. The skill's defaults never replace an explicit brief.

Activation: “Use this skill as the operating specification for this editing assignment. Discover your actual environment, resolve the separately supplied brief/assets, execute the requested scope, run evidence-based release gates, and deliver finished media plus editable source. Do not inherit historical tool-use or QA results.”

## For your builder
Read builder/BUILD_BRIEF.md. Implement the portable execution layer, adapters, components and tests defined here. The builder should build and verify the skill, not return another high-level plan unless a genuine authorization blocker exists. Use builder/ACCEPTANCE_TESTS.md as the implementation finish line.

## What this ZIP contains
Instructions, requirements, machine-readable contracts, defaults, examples, reference style directions and acceptance cases. No campaign footage, photos, music, fonts, recordings, binaries or installed dependencies. JSON templates are explicitly templates; example job IDs and media paths are synthetic.

## Important distinction
This is a complete authoring specification and operating skill, not proof that a portable execution runtime has already been implemented or tested. A computer-capable agent can implement/use it; your builder must pass acceptance tests before describing the execution system as production-ready. The package validation report validates the instruction package and its internal contracts, not unseen edited videos.

## Keep assets separate
Assets live under the job's asset_root. Instructions live under skill_root. Working files, caches, QA evidence and deliverables live under a versioned project_root. Never mix private campaign media into a reusable instruction ZIP.

## Contents
SKILL.md → instructions/00–17 → profiles/ → schemas/ → templates/ → builder/ → examples/ → reference/.
