# Supplied reference provenance

The106 text-only Chron style directions were carried from the user’s earlier instruction archive. They are creative reference data,not an installed engine or a certification of licenses/runtime compatibility. No prior campaign execution statuses carry over.
