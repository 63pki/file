# Supplied skill/library onboarding

A folder/link/archive is not an activated capability. Inventory supplied Remotion/Hyperframes/Tesseract skills,Chron/Antigravity/Vox instructions,the20-style motion pack,caption/effect specs,pastel packs and any additional user tools. Read relevant technical instructions,verify files/version/license,identify a concrete need,then implement/test and record actual use. Do not execute arbitrary bundled scripts without review.

Preserve creative references and rule authority separately. A language-specific reel skill does not change the campaign language. A landscape vendor default does not override a9:16brief. Chron cards do not install an engine. A native sample project does not prove the native tool rendered the deliverable. A sound helper described in docs is not necessarily present on disk.

For every supplied REQUIRED tool/capability,record whether it was used,partially used or tested-blocked. For unneeded alternatives,briefly state why;do not install all competing editors. For relevant untested tools,use NOT_CHECKED,not “incompatible.” A bounded capability router replaces both blind tool accumulation and habitual one-tool editing.

The106-card catalog included here is text-only from the earlier supplied instruction archive. Other packs are referenced rather than silently bundled;the current agent must resolve any separately supplied assets/code. No third-party binary,recording,font or original media is included in this instruction package.
