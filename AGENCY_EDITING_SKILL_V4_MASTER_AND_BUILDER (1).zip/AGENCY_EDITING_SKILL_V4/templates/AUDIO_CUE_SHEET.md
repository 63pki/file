# Audio cue sheet — fresh execution

|Cue ID|Clip/time|Role/intent|Asset/source or generation recipe|License/authorization|Transient/source offset|Gain/envelope|Stem/master route|Hash/evidence|Listening state|
|---|---|---|---|---|---|---|---|---|---|
|TEMPLATE|Not placed|Pending|Pending|UNVERIFIED|Pending|Pending|Pending|Pending|NOT_CHECKED|

Keep source recordings and generated accents distinguishable. No fake cached/fresh download history. A nonzero meter does not establish a good cue.
