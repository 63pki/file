# Assumptions and production decisions

|ID|Type|Question/conflict|Decision|Observable reason/source|Affected outputs/rules|Reversible?|Needs user authorization?|Evidence/review state|
|---|---|---|---|---|---|---|---|---|
|TEMPLATE|ASSUMPTION|Pending|Pending|Pending|Pending|Pending|Pending|NOT_CHECKED|

Store concise decisions and tradeoffs,not hidden internal reasoning. Do not invent retrospective rejection reasons for tools never evaluated.
