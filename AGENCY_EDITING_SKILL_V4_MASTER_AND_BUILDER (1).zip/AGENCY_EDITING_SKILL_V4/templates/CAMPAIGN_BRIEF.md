# Current campaign brief — TEMPLATE,not approved content

- Job/client/audience/objective:
- Requested deliverables/count/duration/platform/variants:
- Authoritative brief and reference paths:
- Story premise and required source moments:
- Verified facts/claims/quotes with source evidence:
- Tone,brand palette/fonts/logos and prohibited treatments:
- Disclosure/account/CTA requirements and prohibited wording:
- Source/audio/font/tool rights and explicit exceptions:
- Languages/accessibility:
- Export/audio/color/caption/stem/editable requirements:
- Budget/deadline/approval/publication boundaries:
- Required tool integrations:
- Missing essential inputs:
- [ASSUMPTION] decisions and impact:

Fill from the CURRENT user task and actual assets. Empty values are not approval. No inherited Cane's scope,weight,disclosure or prior PASS state.
