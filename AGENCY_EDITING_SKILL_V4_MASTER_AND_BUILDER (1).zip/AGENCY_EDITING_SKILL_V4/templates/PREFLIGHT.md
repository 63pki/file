# PREFLIGHT — fresh job

Status:NOT_EXECUTED

|Item|Resolved value/evidence|
|---|---|
|Job/revision/profile|Pending|
|Scope and deliverables|Pending|
|Immutable assets/rights/source map|Pending|
|Environment and selected tool route|Pending|
|Mandatory capabilities and blockers|Pending|
|Applicable rule IDs|Pending|
|Effective layout/type/audio/export targets|Pending|
|Required tests and review capabilities|Pending|
|Budget/resource/concurrency|Pending|
|Current assumptions/exceptions|Pending|
|Preserved active jobs/previous outputs|Pending|

Read constitution first. Decide reversible details autonomously;do not invent essential inputs or permissions.
