# Delivery report — TEMPLATE

## Outcome
Requested/completed/blocked deliverables and exact file locations.

## Per-output metadata
Hypothesis,target metric as intent,source story,tools/components actually used,dimensions/FPS/codec/duration,color/audio specification,caption languages and editable project path.

## Measured release results
Per-rule/gate status,coverage,final export hashes,audio readings,protected-zone/media completeness and source/rights checks. Separate technical PASS from perceptual review.

## Tool-use accounting
USED/PARTIAL/NOT_NEEDED/BLOCKED/NOT_CHECKED,with actual artifact/probe evidence and reasons. Required unused tools explicitly listed.

## Creative review
Timecoded findings,comparison to the available reference,what was viewed/listened to and what was not.

## Assumptions/deviations
Material limits,unresolved blockers,permission/rights gaps and permitted exceptions.

## Rebuild/handoff
Editable source,assets linkage,dependency versions,commands,cue sheet,stems,sidecars and package inventory. Never call a plan a finished edit or a metadata-only file a fully editable timeline.
