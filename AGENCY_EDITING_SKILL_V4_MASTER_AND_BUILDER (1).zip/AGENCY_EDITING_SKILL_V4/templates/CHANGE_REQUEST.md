# Change request

- New revision ID:
- User request and timestamp:
- Additive or replacement scope:
- Deliverables changed/unchanged:
- Explicit rule/profile exceptions:
- Dependency impact:source/crop/caption/audio/color/compositor/export:
- Evidence invalidated and gates to rerun:
- Active renders preserved/queued:
- Required approval or blocker:
- Acceptance result:
