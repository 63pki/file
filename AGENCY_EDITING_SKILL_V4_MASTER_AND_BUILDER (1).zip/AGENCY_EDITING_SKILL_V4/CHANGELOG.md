# Changelog

##4.0.0 — agency-wide portable specification
Separated operating instructions from assets and runtime implementation. Added environment discovery/capability routing,engine-neutral contracts,source/rights/editorial intelligence,complete sound route,protected layout,format profiles,QA/perceptual separation,resource/revision operations,tool evidence and builder acceptance criteria. Carried the106 text-only style directions as reference data. No historical campaign PASS/USED state was promoted into this version.

This release does not assert that a runtime builder has implemented or tested the specification. Package checks cover document/schema/template integrity only.
